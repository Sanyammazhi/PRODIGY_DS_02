library(lubridate)

### catalog marketing
cm_1 <- read.csv("~/Documents//ITM/courses/workshop on R/Catalog Marketing.csv")
cm_2 <- read.csv("~/Documents//ITM/courses/workshop on R/cm_2.csv")

str(cm_1)
str(cm_2)

cm <- merge(cm_1, cm_2, by = "Customer")

cm <- na.omit(cm)

str(cm)

# convert to factors one by one
cm$Gender <- as.factor(cm$Gender)
cm$Married <- as.factor(cm$Married)
cm$OwnHome <- as.factor(cm$OwnHome)
cm$Close <- as.factor(cm$Close)
cm$PreviousCustomer <- as.factor(cm$PreviousCustomer)

## for loop
j = 0
for(i in 1:10)
{
  j = j + i
  print(j)
}

# convert to factors in one shot
select <- c("Gender","OwnHome","Married","Close","PreviousCustomer")
for(i in select)
{
  cm[,i] <- as.factor(cm[,i])
}

#descriptive stats
mean(cm$Salary)
summary(cm)
sd(cm$Salary)

## correlation
cor(cm$AmountSpent, cm$Salary)
cor(cm$AmountSpent, cm$Age, method = "pearson")

#create a new df with numeric variables only
cm_new <- Filter(is.numeric, cm)
# correlation matrix
cor(cm_new)
round(cor(cm_new),2)  

# OLS model
cm.lm <- lm(cm$AmountSpent ~ cm$Age+cm$Gender+cm$OwnHome+cm$Married+cm$Close+
                 cm$Children+cm$PreviousCustomer+cm$Salary+cm$PreviousSpent+cm$Catalogs, 
            data = cm)
par(mfrow=c(2,2))
plot(cm.lm)                
par(mfrow=c(1,1))









hist(cm$AmountSpent) # suggests log transformation (make sure there are no zeros)
hist(cm$Salary) # log transformation (no zeros)


# outlier detection
plot(hatvalues(cm.lm), rstudent(cm.lm))
which(hatvalues(cm.lm)>0.022 & abs(rstandard(cm.lm)) > 2) #hat value threshold is 2(p/n) p=11 and n =1000
cm = cm[-c(931,230,107,160),] # remove outliers

cm.lm <- lm(log(cm$AmountSpent) ~ cm$Age+cm$Gender+cm$OwnHome+cm$Married+cm$Close+
                 cm$Children+cm$PreviousCustomer+log(cm$Salary)+cm$PreviousSpent+cm$Catalogs, data = cm)
par(mfrow=c(2,2))
plot(cm.lm)                
par(mfrow=c(1,1))
summary(cm.lm)
